<div class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container"><img class="navbar-brand" src="img/meatingLogo3.png"   HEIGHT="100px" ></img> <!--style="width: 150px; height: auto;-->
          <div class="navbar-header">
              <a class="navbar-brand">AdE</a>
          </div>
          <div class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
              <li><a href="/">Inicio</a></li>
              <li><a href="/about">¿Que es Asador de Eventos?</a></li>
              <li><a href="/aboutUs">¿Quienes somos?</a></li> 
              <li><a href="/contacto">Contacto</a></li>           
            </ul>
            <ul class="nav navbar-nav navbar-right">
              <li><a href="/login">Inicio de Sesion</a></li> 
              <li><a href="/registro">Registrarse</a></li>
            </ul>
          </div><!--/.nav-collapse -->
        </div>
    </div>