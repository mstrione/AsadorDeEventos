<html>
	<head></head>
	<body>
		<p>Hola! {{$nombre}}, se lo ha invitado a  participar de un evento creado por   </p>
		<p>para poder ver la informacion del evento lo invitamos a iniciar sesion o registrarse en: </p>
		
	</body>
</html>