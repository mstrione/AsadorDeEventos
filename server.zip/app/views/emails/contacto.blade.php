<html>
	<head></head>
	<body>
		<p>Nombre del contacto: {{$nombre}} </p>
		<p>Email del contacto: {{$email}}</p>
		<p>Asunto: {{$asunto}}</p>
		<p>Mensaje: {{$mensaje}}</p>
	</body>
</html>