<?php

class MisEvento extends Eloquent {
	protected $table='eventos';
}